<p align="center">
    Coin Management-Laravel
</p>

## About Coin Management-Laravel

Larave version Laravel 8.83.16
PHP  version: 8.1.7

## Coin Management Website Login page
 <img src="https://github.com/amal-work/Laravel-coin-Management/blob/main/login-page.png" width="550" alt="Coin Management-Laravel"/>

## Coin Management Website Login page
<img src="https://github.com/amal-work/Laravel-coin-Management/blob/main/credit-card.png" width="550" alt="Coin Management-Laravel" />