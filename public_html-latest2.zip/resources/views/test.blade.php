
<html>
    <head>

    </head>
    <body>
        @section('content')
        @endsection
        {!! $data !!}
    </body>
</html>