@extends('include')
@section('content')
<h1>
  Hello World!
</h1>
@stop